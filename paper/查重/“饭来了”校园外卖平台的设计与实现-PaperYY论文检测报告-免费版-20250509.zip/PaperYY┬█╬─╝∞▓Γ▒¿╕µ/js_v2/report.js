var aigcReportLock = true;
var aigcReportSimilarity = "23.9%";
var aigcReportUrl = "https://report.paperyy.com/20250509/9-d8603dbdfba64d49ac01ba43f2b3c3d2-aigc/contrast.html?AccessKeyId=HBDT3R50QARZFDNEE0FT&Expires=1747362607&Signature=vHRSyE%2BJ04KL21OJwTyKBx6MALI%3D";
var zipReportUrl = "https://report.paperyy.com/20250509/9-7c021d54-da72-4852-bc15-565f0ca2f6a3/report.zip?AccessKeyId=HBDT3R50QARZFDNEE0FT&Expires=1747362607&Signature=m4UqOX8pCGcIQt12tZf1i49D2ag%3D";

