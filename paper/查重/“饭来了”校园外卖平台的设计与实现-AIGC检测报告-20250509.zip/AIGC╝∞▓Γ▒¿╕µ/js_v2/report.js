var reportLock = true;
var reportSimilarity = "3.8%";
var reportUrl = "https://report.paperyy.com/20250509/9-7c021d54-da72-4852-bc15-565f0ca2f6a3/contrast.html?AccessKeyId=HBDT3R50QARZFDNEE0FT&Expires=1747362613&Signature=pytPDS/A769eRqLgsu0RmK0BLV8%3D";
var zipReportUrl = "https://report.paperyy.com/20250509/9-d8603dbdfba64d49ac01ba43f2b3c3d2-aigc/report.zip?AccessKeyId=HBDT3R50QARZFDNEE0FT&Expires=1747362613&Signature=PVDV/MelK6XuTDTXj2u115r5nNg%3D";
